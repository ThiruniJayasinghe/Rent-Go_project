<?php
 






$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydriver";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (isset($_POST['driver_name'], $_POST['driver_phone'], $_POST['driver_address'])) {
    $stmt = $conn->prepare("INSERT INTO driver (dname, dphone, daddress) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $_POST['driver_name'], $_POST['driver_phone'], $_POST['driver_address']);

    if ($stmt->execute()) {
        echo "Driver information submitted successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}



$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydriver";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT * FROM driver";
$result = $conn->query($sql);



if (isset($_POST['delete'])) {
    $driverId = $_POST['delete'];

    $deleteStmt = $conn->prepare("DELETE FROM driver WHERE id = ?");
    $deleteStmt->bind_param("i", $driverId);

    if ($deleteStmt->execute()) {
        echo "Driver deleted successfully!";
    } else {
        echo "Error deleting driver: " . $deleteStmt->error;
    }

    $deleteStmt->close();

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

if (isset($_POST['update'], $_POST['driver_id'], $_POST['driver_name_update'], $_POST['driver_phone_update'], $_POST['driver_address_update'])) {
    $driverId = $_POST['driver_id'];
    $driverName = $_POST['driver_name_update'];
    $driverPhone = $_POST['driver_phone_update'];
    $driverAddress = $_POST['driver_address_update'];

    $updateStmt = $conn->prepare("UPDATE driver SET dname = ?, dphone = ?, daddress = ? WHERE id = ?");
    $updateStmt->bind_param("sssi", $driverName, $driverPhone, $driverAddress, $driverId);

    if ($updateStmt->execute()) {
        echo "Driver updated successfully!";
    } else {
        echo "Error updating driver: " . $updateStmt->error;
    }

    $updateStmt->close();

    // Redirect to refresh the page
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}


if ($result->num_rows > 0) {
  echo '<table style="border-collapse: collapse; width: 600px;">';
  echo '<tr>';
  echo '<th style="border: 1px solid black; padding: 8px;">Driver ID</th>';
  echo '<th style="border: 1px solid black; padding: 8px;">Driver Name</th>';
  echo '<th style="border: 1px solid black; padding: 8px;">Driver Phone Number</th>';
  echo '<th style="border: 1px solid black; padding: 8px;">Driver Address</th>';
  echo '<th style="border: 1px solid black; padding: 8px;">Actions</th>';
  echo '</tr>';

  while ($row = $result->fetch_assoc()) {
      echo '<tr>';
      echo '<td style="border: 1px solid black; padding: 8px;">' . $row["id"] . '</td>';
      echo '<td style="border: 1px solid black; padding: 8px;">' . $row["dname"] . '</td>';
      echo '<td style="border: 1px solid black; padding: 8px;">' . $row["dphone"] . '</td>';
      echo '<td style="border: 1px solid black; padding: 8px;">' . $row["daddress"] . '</td>';
      echo '<td style="border: 1px solid black; padding: 8px;">';
      echo '<form action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '" method="POST">';
      echo '<input type="hidden" name="delete" value="' . $row["id"] . '">';
      echo '<button type="submit">Delete</button>';
      echo '</form>';
      echo '</form>';
      echo '<form action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '" method="POST">';
      echo '<input type="hidden" name="update" value="true">';
      echo '<input type="hidden" name="driver_id" value="' . $row["id"] . '">';
      echo 'Name: <input type="text" name="driver_name_update" value="' . $row["dname"] . '">';
      echo 'Phone: <input type="text" name="driver_phone_update" value="' . $row["dphone"] . '">';
      echo 'Address: <input type="text" name="driver_address_update" value="' . $row["daddress"] . '">';
      echo '<button type="submit">Update</button>';
      echo '</form>';
      echo '</td>';
      echo '</tr>';
  }

  echo "</table>";
} else {
    echo "No data found in the drivers table.";
}


$conn->close();







?>